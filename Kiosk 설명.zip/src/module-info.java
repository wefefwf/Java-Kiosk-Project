/**
 * 
 */
/**
 * 
 */
module Kiosk {
}